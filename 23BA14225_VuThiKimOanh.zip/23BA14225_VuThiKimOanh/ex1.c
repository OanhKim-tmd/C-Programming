#include <stdio.h>
int main(){
    printf("\"This\'s our C programming course\"\n\"Welcome to the first tutorial class\"\n");
    return 0;
}